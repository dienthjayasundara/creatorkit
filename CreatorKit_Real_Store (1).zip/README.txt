CreatorKit Store

WHAT IS INCLUDED
- Polished responsive storefront
- 6 demo digital products
- Working cart with localStorage
- Quantity tracking and totals
- Customer email field
- Checkout-ready flow
- Mobile-friendly design

IMPORTANT FOR REAL PAYMENTS
The checkout in this starter is intentionally a demo. To accept real money, connect the checkout button to a legitimate payment processor and a digital-download delivery system. Do not put secret API keys in this HTML file.

Also replace the demo products with digital products you created or have permission to sell.

If you are under 18, a parent/guardian may need to own or supervise the payment account depending on the provider and local rules.
